/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

#include <stdio.h>
#include "ssd1306.h"
#include "ssd1306_fonts.h"
#include "stdio.h"
#include "string.h"
#include "stm32f1xx_hal.h"

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define MPU6050_ADDR 0xD0
#define WHO_AM_I_REG 0x75
#define PWR_MGMT_1_REG 0x6B
#define SMPLRT_DIV_REG 0x19
#define ACCEL_CONFIG_REG 0x1C
#define GYRO_CONFIG_REG 0x1B
#define ACCEL_XOUT_H_REG 0x3B
#define GYRO_XOUT_H_REG 0x43

#define BENT_THRESHOLD 300
#define FLAT_THRESHOLD 600
#define HALF_BENT_MAX 600
#define HALF_BENT_MIN 300


/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
ADC_HandleTypeDef hadc1;
DMA_HandleTypeDef hdma_adc1;
I2C_HandleTypeDef hi2c1;
UART_HandleTypeDef huart2;

/* USER CODE BEGIN PV */
int16_t accel_x, accel_y, accel_z;
int16_t gyro_x, gyro_y, gyro_z;
uint32_t flex[5] ;
volatile uint8_t dma_complete = 0 ;
//float Thumb;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_DMA_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_I2C1_Init(void);
static void MX_ADC1_Init(void);
/* USER CODE BEGIN PFP */

void MPU6050_Init(void);
void MPU6050_Read_Accel(void);
void MPU6050_Read_Gyro(void);
void Flex_Sensors_Start(void);
char Get_Letter (void);

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

void MPU6050_Init(void){
	uint8_t check;
	uint8_t data;

	HAL_I2C_Mem_Read(&hi2c1, MPU6050_ADDR, WHO_AM_I_REG, 1, &check, 1, 1000);
	if (check == 0x68){

		data = 0x00;
		HAL_I2C_Mem_Write(&hi2c1, MPU6050_ADDR, PWR_MGMT_1_REG, 1, &data, 1, 1000);

		data = 0x07;
		HAL_I2C_Mem_Write(&hi2c1, MPU6050_ADDR, SMPLRT_DIV_REG, 1, &data, 1, 1000);

		data = 0x00;
		HAL_I2C_Mem_Write(&hi2c1, MPU6050_ADDR, ACCEL_CONFIG_REG, 1, &data, 1, 1000);

		data = 0x00;
		HAL_I2C_Mem_Write(&hi2c1, MPU6050_ADDR, GYRO_CONFIG_REG, 1, &data, 1, 1000);
	}
}

void MPU6050_Read_Accel(void){
	uint8_t data [6];

	HAL_I2C_Mem_Read(&hi2c1, MPU6050_ADDR, ACCEL_XOUT_H_REG, 1, data, 6, 1000);

	accel_x = (int16_t)(data[0] << 8 | data[1]);
	accel_y = (int16_t)(data[2] << 8 | data[3]);
	accel_z = (int16_t)(data[4] << 8 | data[5]);
}

void MPU6050_Read_Gyro(void){
	uint8_t data [6];

	HAL_I2C_Mem_Read(&hi2c1, MPU6050_ADDR, GYRO_XOUT_H_REG, 1, data, 6, 1000);

	gyro_x = (int16_t)(data[0] << 8 | data[1]);
	gyro_y = (int16_t)(data[2] << 8 | data[3]);
	gyro_z = (int16_t)(data[4] << 8 | data[5]);
}

void Flex_Sensors_Start(void){
	HAL_ADC_Stop(&hadc1);
	if (HAL_ADC_Start_DMA(&hadc1, flex, 5) != HAL_OK){
		ssd1306_Fill(Black);
		ssd1306_SetCursor(0, 0);
		ssd1306_WriteString("DMA Fail", Font_7x10, White);
		ssd1306_UpdateScreen();
		HAL_Delay(2000);
		Error_Handler();
	}
}
void HAL_ADC_ConvCpltCallback (ADC_HandleTypeDef* hadc) {
	if (hadc == &hadc1) {
		dma_complete =1 ;
	}
}



char Get_Letter(void) {

    int thumb = (flex[0] < BENT_THRESHOLD) ? 2 : (flex[0] <= HALF_BENT_MAX && flex[0] >= HALF_BENT_MIN) ? 1 : 0;
    int index = (flex[1] < BENT_THRESHOLD) ? 2 : (flex[1] <= HALF_BENT_MAX && flex[1] >= HALF_BENT_MIN) ? 1 : 0;
    int middle = (flex[2] < BENT_THRESHOLD) ? 2 : (flex[2] <= HALF_BENT_MAX && flex[2] >= HALF_BENT_MIN) ? 1 : 0;
    int ring = (flex[3] < BENT_THRESHOLD) ? 2 : (flex[3] <= HALF_BENT_MAX && flex[3] >= HALF_BENT_MIN) ? 1 : 0;
    int pinky = (flex[4] < BENT_THRESHOLD) ? 2 : (flex[4] <= HALF_BENT_MAX && flex[4] >= HALF_BENT_MIN) ? 1 : 0;


    int base1_x = (accel_x > -11000 && accel_x < -17000);
    int base1_y = (accel_y > 0 && accel_y < 6000);
    int base1_z = (accel_z > 3000 && accel_z < 7000);


    int base2_x = (accel_x < -11000 && accel_x > -17000);
    int base2_y = (accel_y > -4000 && accel_y < 2000);
    int base2_z = (accel_z > 1000 && accel_z < 7000);


    int base3_x = (accel_x < -6000 && accel_x > -10000);
    int base3_y = (accel_y < -11000 && accel_y > -17000);
    int base3_z = (accel_z > 0 && accel_z < 4000);


    int base4_x = (accel_x > 4000 && accel_x < 10000);
    int base4_y = (accel_y > -6000 && accel_y < 0);
    int base4_z = (accel_z > 10000 && accel_z < 16000);

    /*
    if (thumb == 2 && index == 0  ) return 'T';

    if (thumb == 0 && index == 2 ) return 'I';

    if (middle == 2 && ring == 0) return 'M';

    if (ring == 2 && pinky == 0) return 'R';

    if (middle == 0 && ring == 0 && pinky == 2) return 'P';

    if (thumb == 0 && index == 0 && middle == 0 && ring == 0 && pinky == 2 && base1_x && base1_y && base1_z) return 'P';

    */

    if (thumb == 0 && index == 2 && middle == 2 && ring == 2 && pinky == 2 && base1_x && base1_y && base1_z) return 'A';

    if (thumb == 2 && index == 0 && middle == 0 && ring == 0 && pinky == 0 && base1_x && base1_y && base1_z) return 'B';

    if (thumb == 1 && index == 1 && middle == 1 && ring == 1 && pinky == 1 && base2_x && base2_y && base2_z) return 'C';

    if (thumb == 2 && index == 0 && middle == 2 && ring == 2 && pinky == 2 && base2_x && base2_y && base2_z) return 'D';

    if (thumb == 1 && index == 2 && middle == 2 && ring == 2 && pinky == 2 && base1_x && base1_y && base1_z) return 'E';

    if (thumb == 2 && index == 2 && middle == 0 && ring == 0 && pinky == 0 && base1_x && base1_y && base1_z) return 'F';

    if (thumb == 0 && index == 0 && middle == 2 && ring == 2 && pinky == 2 && base3_x && base3_y && base3_z) return 'G';

    if (thumb == 0 && index == 0 && middle == 0 && ring == 2 && pinky == 2 && base3_x && base3_y && base3_z) return 'H';

    if (thumb == 0 && index == 2 && middle == 0 && ring == 0 && pinky == 0 && base1_x && base1_y && base1_z) return 'I';

    if (thumb == 2 && index == 2 && middle == 2 && ring == 2 && pinky == 0 && base1_x && base1_y && base1_z) return 'J';

    if (thumb == 0 && index == 0 && middle == 0 && ring == 2 && pinky == 2 && base1_x && base1_y && base1_z) return 'K';

    if (thumb == 0 && index == 0 && middle == 2 && ring == 2 && pinky == 2 && base1_x && base1_y && base1_z) return 'L';

    if (thumb == 0 && index == 0 && middle == 2 && ring == 0 && pinky == 0 && base1_x && base1_y && base1_z) return 'M';



    if (thumb == 1 && index == 2 && middle == 2 && ring == 2 && pinky == 2 && base2_x && base2_y && base2_z) return 'O';

    if (thumb == 0 && index == 0 && middle == 0 && ring == 2 && pinky == 2 && base4_x && base4_y && base4_z) return 'P';

    if (thumb == 0 && index == 0 && middle == 2 && ring == 2 && pinky == 2 && base4_x && base4_y && base4_z) return 'Q';

    if (thumb == 1 && index == 0 && middle == 0 && ring == 2 && pinky == 2 && base1_x && base1_y && base1_z) return 'R';

    if (thumb == 2 && index == 2 && middle == 2 && ring == 2 && pinky == 2 && base1_x && base1_y && base1_z) return 'S';

    if (thumb == 1 && index == 0 && middle == 0 && ring == 0 && pinky == 0 && base1_x && base1_y && base1_z) return 'T';

    if (thumb == 1 && index == 0 && middle == 0 && ring == 2 && pinky == 2 && base1_x && base1_y && base1_z) return 'U';

    if (thumb == 2 && index == 0 && middle == 0 && ring == 2 && pinky == 2 && base1_x && base1_y && base1_z) return 'V';

    if (thumb == 2 && index == 0 && middle == 0 && ring == 0 && pinky == 2 && base1_x && base1_y && base1_z) return 'W';

    if (thumb == 2 && index == 0 && middle == 2 && ring == 2 && pinky == 2 && base1_x && base1_y && base1_z) return 'X';

    if (thumb == 0 && index == 2 && middle == 2 && ring == 2 && pinky == 0 && base1_x && base1_y && base1_z) return 'Y';

    if (thumb == 1 && index == 0 && middle == 2 && ring == 2 && pinky == 2 && base1_x && base1_y && base1_z) return 'Z';

    // Lauren s added code

    if (thumb == 0 && index == 0 && middle == 2 && ring == 2 && pinky == 0 && base1_x && base1_y && base1_z) return '1';
    // '1' for  I love you   ended
    return ' ';
}


// Also Laurens added code for Gesture

char Get_Gesture(void) {

	// Read accelerometer data

	MPU6050_Read_Accel();

	// Define the "Thank you" gesture ranges based on the new data

	    int thank_you_y = (accel_y > -3000 && accel_y < 3000); // Adjusted range for Ay

	    int thank_you_z = (accel_z < -18000); // Adjusted threshold for Az



	    // Check if the MPU-6050 is in the "Thank you" position

	    if (thank_you_y && thank_you_z) {

	        return '2'; // Return '2' to indicate "Thank you"

	    }



	    return ' '; // Return space if no gesture is detected

	}
// Ended
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */
	char buffer[64];
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_USART2_UART_Init();
  MX_I2C1_Init();
  MX_ADC1_Init();
  /* USER CODE BEGIN 2 */
  MPU6050_Init();
  ssd1306_Init();



  ssd1306_Fill(Black);
  ssd1306_SetCursor(5 ,5 );
  ssd1306_WriteString("Starting....." , Font_7x10 , White);
  ssd1306_UpdateScreen();
  HAL_Delay(5000);

  memset(flex, 0 , sizeof(flex));
  Flex_Sensors_Start();



  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
	  MPU6050_Read_Accel();
	  MPU6050_Read_Gyro();




	  ssd1306_Fill(Black);

	  ssd1306_SetCursor(5, 18);
	  snprintf(buffer, sizeof(buffer), "Ax:%.2d  Gx:%.2d", accel_x, gyro_x);
	  ssd1306_WriteString(buffer, Font_7x10, White);

	  ssd1306_SetCursor(5, 35);
      snprintf(buffer, sizeof(buffer), "Ay:%.2d  Gy:%.2d", accel_y, gyro_y);
	  ssd1306_WriteString(buffer, Font_7x10, White);

	  ssd1306_SetCursor(5, 50);
	  snprintf(buffer, sizeof(buffer), "Az:%.2d  Gz:%.2d", accel_z, gyro_z);
	  ssd1306_WriteString(buffer, Font_7x10, White);


	  ssd1306_UpdateScreen();
	  HAL_Delay(2000);

	  ssd1306_Fill(Black);


	  ssd1306_SetCursor(5, 5);
	  snprintf(buffer, sizeof(buffer), "Thumb: %1lu ", flex[0]);
	  ssd1306_WriteString(buffer, Font_7x10, White);

	  ssd1306_SetCursor(5, 17);
	  snprintf(buffer, sizeof(buffer), "Index: %1lu ", flex[1]);
	  ssd1306_WriteString(buffer, Font_7x10, White);

	  ssd1306_SetCursor(5,29 );
	  snprintf(buffer, sizeof(buffer), "Middle: %1lu ", flex[2]);
	  ssd1306_WriteString(buffer, Font_7x10, White);

	  ssd1306_SetCursor(5, 41);
	  snprintf(buffer, sizeof(buffer), "Ring: %1lu ", flex[3] );
	  ssd1306_WriteString(buffer, Font_7x10, White);

	  ssd1306_SetCursor(5, 53);
	  snprintf(buffer, sizeof(buffer), "Pinky: %1lu ", flex[4] );
	  ssd1306_WriteString(buffer, Font_7x10, White);

	  ssd1306_UpdateScreen();
	  HAL_Delay(2000);

	  char letter = Get_Letter();

      char gesture = Get_Gesture();

//     ssd1306_Fill(Black);

//	  ssd1306_SetCursor(10,15 );
//	  snprintf(buffer, sizeof(buffer), " %c" , letter);
//	  ssd1306_WriteString(buffer, Font_16x26, White);

//	  ssd1306_UpdateScreen();
//	  HAL_Delay(2000);

// Laurens added code start

      if (gesture == '2') {

          // Display "Thank you" on the OLED screen

          ssd1306_SetCursor(10, 15);

          ssd1306_WriteString("Thank you", Font_7x10, White);

      } else if (letter == '1') {

          // Display "I love you" on the OLED screen

          ssd1306_SetCursor(10, 15);

          ssd1306_WriteString("I love you", Font_7x10, White);

      } else if (letter != ' ') {

          // Display the detected letter

          ssd1306_SetCursor(10, 15);

          snprintf(buffer, sizeof(buffer), "%c", letter); // Format the letter as a string

          ssd1306_WriteString(buffer, Font_16x26, White);

      }



	  ssd1306_UpdateScreen();

	  HAL_Delay(2000);
// Ended

    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL7;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_ADC;
  PeriphClkInit.AdcClockSelection = RCC_ADCPCLK2_DIV4;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief ADC1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_ADC1_Init(void)
{

  /* USER CODE BEGIN ADC1_Init 0 */

  /* USER CODE END ADC1_Init 0 */

  ADC_ChannelConfTypeDef sConfig = {0};

  /* USER CODE BEGIN ADC1_Init 1 */

  /* USER CODE END ADC1_Init 1 */

  /** Common config
  */
  hadc1.Instance = ADC1;
  hadc1.Init.ScanConvMode = ADC_SCAN_ENABLE;
  hadc1.Init.ContinuousConvMode = ENABLE;
  hadc1.Init.DiscontinuousConvMode = DISABLE;
  hadc1.Init.ExternalTrigConv = ADC_SOFTWARE_START;
  hadc1.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc1.Init.NbrOfConversion = 5;
  if (HAL_ADC_Init(&hadc1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Regular Channel
  */
  sConfig.Channel = ADC_CHANNEL_0;
  sConfig.Rank = ADC_REGULAR_RANK_1;
  sConfig.SamplingTime = ADC_SAMPLETIME_239CYCLES_5;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Regular Channel
  */
  sConfig.Channel = ADC_CHANNEL_1;
  sConfig.Rank = ADC_REGULAR_RANK_2;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Regular Channel
  */
  sConfig.Channel = ADC_CHANNEL_4;
  sConfig.Rank = ADC_REGULAR_RANK_3;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Regular Channel
  */
  sConfig.Channel = ADC_CHANNEL_8;
  sConfig.Rank = ADC_REGULAR_RANK_4;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Regular Channel
  */
  sConfig.Channel = ADC_CHANNEL_11;
  sConfig.Rank = ADC_REGULAR_RANK_5;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN ADC1_Init 2 */

  /* USER CODE END ADC1_Init 2 */

}

/**
  * @brief I2C1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C1_Init(void)
{

  /* USER CODE BEGIN I2C1_Init 0 */

  /* USER CODE END I2C1_Init 0 */

  /* USER CODE BEGIN I2C1_Init 1 */

  /* USER CODE END I2C1_Init 1 */
  hi2c1.Instance = I2C1;
  hi2c1.Init.ClockSpeed = 400000;
  hi2c1.Init.DutyCycle = I2C_DUTYCYCLE_2;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C1_Init 2 */

  /* USER CODE END I2C1_Init 2 */

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * Enable DMA controller clock
  */
static void MX_DMA_Init(void)
{

  /* DMA controller clock enable */
  __HAL_RCC_DMA1_CLK_ENABLE();

  /* DMA interrupt init */
  /* DMA1_Channel1_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Channel1_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA1_Channel1_IRQn);

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
/* USER CODE BEGIN MX_GPIO_Init_1 */
/* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(LD2_GPIO_Port, LD2_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : B1_Pin */
  GPIO_InitStruct.Pin = B1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(B1_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : LD2_Pin */
  GPIO_InitStruct.Pin = LD2_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(LD2_GPIO_Port, &GPIO_InitStruct);

  /* EXTI interrupt init*/
  HAL_NVIC_SetPriority(EXTI15_10_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI15_10_IRQn);

/* USER CODE BEGIN MX_GPIO_Init_2 */
/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
	  HAL_GPIO_TogglePin(LD2_GPIO_Port, LD2_Pin);  // Toggle LED if available
	          HAL_Delay(500);
  }
}
  /* USER CODE END Error_Handler_Debug */


#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
